_________________________________________

Author	      : hotfloppy
Email 	      : hotfloppy@malaysia.com
App. Name     : Command & Conquer Generals +3
Type  	      : trainer
Release Date  : 31 March 2004
Update	      : -  05 April 2004
		-  18 April 2004

_________________________________________

Update *
- Power supply error fixed. 		(05 April 2004)
- Added unlimited exp. points option 	(18 April 2004)

Any comment or suggestion, feel free to send me an email with 'generals' 
as a sucject. Enjoy!

Greets
------

Bie, a_jaxxx, extalia & devious forum, all gamehackers around the world - 
you know who you are.