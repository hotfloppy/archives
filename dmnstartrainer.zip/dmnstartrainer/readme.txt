_________________________________________

Author	      : hotfloppy
Email 	      : hotfloppy@malaysia.com
App. Name     : DemonStar v4.04 +2
Type  	      : trainer
Release Date  : 4 April 2004

_________________________________________

Words:

- Life, bomb and shield option worked for both player.

- If you've enabled bomb option (hotkey : F4), you might want to disable it
  later on the game to get better bomb. :)

- Life option   : not recommended.
- Shield option : recommended.
- Ghost option  : higher recommended.

Any comment or suggestion, feel free to send me an email with 'demonstar' 
as a sucject. Enjoy!

Greets
------

Bie, a_jaxxx, all gamehackers around the world - you know who you are.

Special Greets
--------------

Bie - beta tester, better hotkey.