_________________________________________

Author	      : hotfloppy
Email 	      : hotfloppy@malaysia.com
App. Name     : Super Collapse! II v1.33 +3
Type  	      : trainer
Release Date  : 29 February 2004
Update	      : - 22 May 2004 (Crazy score option removed)

_________________________________________

I make this trainer based on Super Collapse! II trial version. I didnt try it with
full version. PLEASE DO NOT TELL ME THAT THIS TRAINER WONT WORK ON FULL VERSION OF SUPER COLLAPSE! II.

Any comment or suggestion, feel free to send me an email with 'collapse!' as a subject.

Option instruction
Press
	1 : Freeze lines
	2 : Back to normal

	3 : 1 line to next level
	4 : Back to normal

	5 : Add 999 score every collapse
	6 : Back to normal

	7 : Trial time will stay 15 (notes)

	X : Exit trainer


Notes : Trial time will stay 15 in-game only. If you close the game, it will 	change to back to the true time. Just use this option in-game and 		you can play as long as you want ;)

Greets fly to 
Bie - my guru & friend
a-jaxxx(razak_kadir76@hotmail.com) - my friend
and all gamehackers around the world - you know who you are.
